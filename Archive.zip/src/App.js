import logo from './logo.svg';
import { SchoolManagement } from './components/SchoolManagement';

function App() {
  return (
    <div className="App">
      <SchoolManagement />
    </div>
  );
}

export default App;
